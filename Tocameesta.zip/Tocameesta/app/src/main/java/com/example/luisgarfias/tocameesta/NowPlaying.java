package com.example.luisgarfias.tocameesta;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class NowPlaying extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_now_playing);
    }
}
